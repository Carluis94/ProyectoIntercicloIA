# digit-recognition-python
A simple example to recognize digits with skit learn
